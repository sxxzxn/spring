package net.fullstack7.springvboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringvbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
