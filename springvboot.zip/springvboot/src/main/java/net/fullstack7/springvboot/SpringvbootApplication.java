package net.fullstack7.springvboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringvbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringvbootApplication.class, args);
	}

}
